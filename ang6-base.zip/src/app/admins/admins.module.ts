import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminLogoutComponent } from './admin-logout/admin-logout.component';

@NgModule({
  imports: [
    FormsModule,
    CommonModule
  ],
  declarations: [
    AdminLoginComponent,
    AdminLogoutComponent
  ]
})
export class AdminsModule { }
