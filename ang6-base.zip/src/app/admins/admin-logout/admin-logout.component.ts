import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'a6b-admin-logout',
  templateUrl: './admin-logout.component.html',
  styleUrls: ['./admin-logout.component.css']
})
export class AdminLogoutComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit() {
    $(document).prop('title', 'Desconexión');
    localStorage.setItem('token', null);
    sessionStorage.removeItem('LastEditedName');
    this.router.navigateByUrl('');
  }
}
