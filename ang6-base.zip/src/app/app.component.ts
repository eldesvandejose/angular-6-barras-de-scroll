import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'a6b-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, DoCheck {
  public lastEdited: string;
  public nombreAdmin: string;
  public rolAdmin: string;

  constructor() {}

  ngOnInit() {}

  ngDoCheck() {
    this.lastEdited = sessionStorage.getItem('LastEditedName');
    this.nombreAdmin = localStorage.getItem('nombreAdmin');
    this.rolAdmin = localStorage.getItem('rolAdmin');
  }
}
