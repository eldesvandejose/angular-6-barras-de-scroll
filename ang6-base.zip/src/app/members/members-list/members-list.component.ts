import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  ViewChild,
  Renderer} from '@angular/core';
import { Router } from '@angular/router';
/* Dos importaciones necesarias para poder crear una instancia de la tabla
y manejarla como un objeto Subject */
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
/* Importamos la clase Member que necesitaremos para
gestionar los objetos de los usuarios. */
import { Member } from '../classes/member';
import { DataTablesResponse } from '../classes/data-tables-response';
import { CheckAdminService } from '../../services/check-admin.service';
import { HttpConnectService } from '../services/http-connect.service';
import { HttpErrorResponse } from '@angular/common/http';

declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'a6b-members-list',
  templateUrl: './members-list.component.html',
  styleUrls: ['./members-list.component.css']
})
export class MembersListComponent implements AfterViewInit, OnDestroy, OnInit {
  /* El decorador @ViewChild recibe la clase DataTableDirective, para luego poder
  crear el dtElement que represente la tabla que estamos creando. */
  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtTrigger: Subject<DataTableDirective> = new Subject(); // La clase Subject es un genérico, tenemos que atribuirle el tipo adecuado.

  public dtOptions: any = {};

  public nombreParaBorrar: string; // El nombre que se muestra cuando se va a borrar un registro.
  public idParaBorrar: string; // El id del registro que se va a borrar.

  // Mensajes para el usuario
  mensajeProcesoExitoso = false;
  mensajeDeErrorDeAPI = false;
  mensajeDetalladoDeError: string;

  public nombreAdmin: string;
  public rolAdmin: string;

  private botones: any[];
  private buttonsVisibility: boolean;

  public OpcionesDeBarrasDeScroll = {
    axis: 'y',
    theme: 'minimal-dark'
  };

  /* En el constructor creamos el objeto connectService,
  de la clase HttpConnectService, que contiene el servicio mencionado,
  y estará disponible en toda la clase de este componente.
  El objeto es private, porque no se usará fuera de este componente. */
  constructor(
    private router: Router,
    private checkAdmin: CheckAdminService,
    private connectService: HttpConnectService,
    private renderer: Renderer
  ) {}

  /* Al inicio del componente se llevan a cabo varias operaciones:
    - Establecemos el título para la pestaña del navegador.
    - Definimos las opciones de DT.
    - Declaramos las propiedades iniciales del modal que se activará para pedir
      confirmación cuando se solicite el borrado de un miembro. */
  ngOnInit() {
    $(document).prop('title', 'Lista de miembros');
    this.checkAdmin.checkToken();
    if (
      localStorage.getItem('rolAdmin') !== 'ROLE_FULL' &&
      localStorage.getItem('rolAdmin') !== 'ROLE_ADMIN'
    ) {
      this.router.navigateByUrl('forbidden');
    }
    this.nombreAdmin = localStorage.getItem('nombreAdmin');
    this.rolAdmin = localStorage.getItem('rolAdmin');

    $('#modalBorrar').modal({
      backdrop: false,
      keyboard: false,
      show: false
    });

    this.botones = [
      {
        extend: 'print',
        text: 'Imprimir',
        exportOptions: {
          columns: [0, 1, 2]
        },
        className: 'btn btn-success btn-sm',
        autoPrint: true
      },
      {
        extend: 'excel',
        text: 'Exp. Excel',
        exportOptions: {
          columns: [0, 1, 2]
        },
        className: 'btn btn-success btn-sm'
      }
    ];

    const enrutamiento = this.router;
    if (this.rolAdmin === 'ROLE_FULL') {
      this.botones.unshift({
        text: 'Nuevo socio',
        className: 'btn btn-primary btn-sm',
        action: function() {
          enrutamiento.navigateByUrl('members/form');
        }
      });
      this.buttonsVisibility = true;
    } else {
      this.buttonsVisibility = false;
    }

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      serverSide: true,
      processing: true,
      info: true,
      lengthMenu: [[10, 15, 20, 30, 50, -1], [10, 15, 20, 30, 50, 'Todos']],
      language: {
        emptyTable: '',
        zeroRecords: 'No hay coincidencias',
        lengthMenu: 'Mostrar _MENU_ elementos',
        search: 'Buscar:',
        info: 'De _START_ a _END_ de _TOTAL_ elementos',
        infoEmpty: 'De 0 a 0 de 0 elementos',
        infoFiltered: '(filtrados de _MAX_ elementos totales)',
        paginate: {
          first: 'Prim.',
          last: 'Últ.',
          next: 'Sig.',
          previous: 'Ant.'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        this.connectService.http
          .post<DataTablesResponse>(
            this.connectService.URL + 'read_records_dt.php',
            dataTablesParameters,
            {}
          )
          .subscribe(resp => {
            $(
              '.dataTables_length>label>select, .dataTables_filter>label>input'
            ).addClass('form-control-sm');
            $('.dt-button')
              .removeClass('dt-button')
              .css({
                'margin-left': '4px',
                'margin-right': '4px'
              });

            callback({
              recordsTotal: resp.recordsTotal,
              recordsFiltered: resp.recordsFiltered,
              data: resp.data
            });
          });
      },
      columns: [
        {
          title: 'DOI',
          data: 'doi'
        },
        {
          title: 'NOMBRE',
          data: 'nombre'
        },
        {
          title: 'F.INGRESO',
          data: 'fecha_de_ingreso'
        },
        {
          title: 'EDIT',
          width: '50px',
          render: function(data: any, type: any, full: any) {
            let botonEditar =
              '<button class="btn btn-warning btn-sm icon ion-md-create" ';
            botonEditar += 'id="' + full.id + '" name="editButton"></button>';
            return botonEditar;
          },
          seachable: false,
          orderable: false,
          visible: this.buttonsVisibility
        },
        {
          title: 'DEL.',
          width: '50px',
          render: function(data: any, type: any, full: any) {
            let botonEditar =
              '<button class="btn btn-danger btn-sm icon ion-md-trash" ';
            botonEditar +=
              'id="' +
              full.id +
              '" name="deleteButton" value="' +
              full.nombre +
              '"></button>';
            return botonEditar;
          },
          seachable: false,
          orderable: false,
          visible: this.buttonsVisibility
        }
      ],
      dom: 'lBftip',
      buttons: this.botones
    };
  }

  /* El siguiente método está bindeado desde los botones de borrar registros.
  Cuando se pulsa uno de estos botones se activa un modal pidiendo confirmación
  para efectuar el borrado. */
  public preavisoDeBorrado(id: string, nombre: string) {
    this.nombreParaBorrar = nombre;
    this.idParaBorrar = id;
    $('#modalBorrar').modal('show');
  }

  /* Si se cancela el borrado desde el modal de preaviso. */
  public anularBorrado() {
    this.nombreParaBorrar = undefined;
    this.idParaBorrar = undefined;
    $('#modalBorrar').modal('hide');
  }

  /* Si se confirma el borrado, llamamos al método del servicio que se encarga de
  conectar con la API de borrado, pasándole el id del registro que queremos borrar. */
  public confirmarBorrado(id: string) {
    this.connectService
      .deleteRecord$(id)
      .subscribe(this.deleteSuccess.bind(this), this.catchError.bind(this));
  }

  /* Si se ha conseguido borrar el registro, se informa de ello y se actualiza
  la lista de miembros en la vista. Además, se cierra el modal. */
  public deleteSuccess() {
    this.reDraw();
    $('#modalBorrar').modal('hide');
    this.mensajeProcesoExitoso = true;
  }

  /* El siguiente método activa el mensaje de error de API's */
  public catchError(err) {
    this.mensajeDeErrorDeAPI = true;
    if (err instanceof HttpErrorResponse) {
      this.mensajeDetalladoDeError += 'Status: ' + err.status + '. ';
      this.mensajeDetalladoDeError += 'Status text: ' + err.statusText + '. ';
      this.mensajeDetalladoDeError += 'Error: ' + err.message + '. ';
    }
    this.mensajeDetalladoDeError += 'Contacte con el Administrador.';
  }

  /* El siguiente mensaje desactiva el mensaje de error de API's */
  public cleanOperationMessages() {
    this.mensajeDeErrorDeAPI = false;
    this.mensajeProcesoExitoso = false;
  }

  ngAfterViewInit(): void {
    this.renderer.listenGlobal('document', 'click', event => {
      const accion = event.target.name;
      const elemento = event.target.id;
      if (accion === 'editButton') {
        this.router.navigateByUrl('members/form/' + elemento);
      }
      if (accion === 'deleteButton') {
        const nombre = event.target.value;
        this.preavisoDeBorrado(elemento, nombre);
      }
    });
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Hay que dessuscribirse del evento dtTrigger, para poder recrear la tabla.
    this.dtTrigger.unsubscribe();
  }

  reDraw(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destruimos la tabla
      dtInstance.destroy();
      // dtTrigger la reconstruye
      this.dtTrigger.next();
    });
  }
}
